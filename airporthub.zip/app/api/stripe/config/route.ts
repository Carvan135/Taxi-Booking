import { stripePublishableKeyResponse } from "@/lib/stripe/stripe-config-response";

export const dynamic = "force-dynamic";

/** Runtime Stripe.js config — works when NEXT_PUBLIC_* was not inlined at build time. */
export async function GET() {
  return stripePublishableKeyResponse();
}
